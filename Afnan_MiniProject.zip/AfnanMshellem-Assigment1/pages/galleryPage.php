<?php
session_start();
if (!isset($_SESSION["username"])) {
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/styleGallery.css">
    <link rel="stylesheet" href="../css/icons.css">

    <title>Gallery</title>
</head>

<body>
    <div class="row" id="header">
        <div id="dropdown-menu">
            <span><i class="ico burger-ico"></i>MENU</span>
            <div class="dropdown-content">
                <ul>
                    <a href="../indexPage.php">
                        <li><i class="ico ico-l gallery-ico"></i>Main Page</li>
                    </a>
                    <a href="cvPage.php">
                        <li><i class="ico ico-l user-ico"></i>CV</li>
                    </a>
                    <a href="galleryPage.php">
                        <li><i class="ico ico-l wallet-ico"></i>Gallery</li>
                    </a>
                    <a href="contact.php">
                        <li><i class="ico ico-l gallery-ico"></i>Contact</li>
                    </a>

                </ul>
            </div>

        </div>
        <div id="user-welcome">Welcome
        <?php echo $_SESSION["username"]; 
            echo '! <a href="../BE/logout.php"> LogOut 🐇 </a>' ;
            ?>        </div>

    </div>
    <div id="container">
        <div class="gallery">
            <div class="imgs">
                <input type="checkbox" name="" id="zoom_img">
                <label for="zoom_img">
                    <img src="../images/image2.jpg">

                    <p>----</p>
                </label>

            </div>
            <div class="imgs">
                <input type="checkbox" name="" id="zoom_img2">
                <label for="zoom_img2">
                    <img src="../images/image1.jpg">

                    <p>----</p>
                </label>

            </div>
            <div class="imgs">
                <input type="checkbox" name="" id="zoom_img3">
                <label for="zoom_img3">
                    <img src="../images/Henry1.jpg">
                    <p>----</p>
                </label>

            </div>

        </div>
        <div class="gallery">
            <div class="imgs">
                <input type="checkbox" name="" id="zoom_img4">
                <label for="zoom_img4">
                    <img src="../images/image3.jpg">
                    <p>----</p>
                </label>

            </div>
            <div class="imgs">
                <input type="checkbox" name="" id="zoom_img5">
                <label for="zoom_img5">
                    <img src="../images/image5.jpg">

                    <p>----</p>
                </label>

            </div>
            <div class="imgs">
                <input type="checkbox" name="" id="zoom_img6">
                <label for="zoom_img6">
                    <img src="../images/image4.webp">

                    <p>----</p>
                </label>

            </div>

        </div>

    </div>
</body>

</html>